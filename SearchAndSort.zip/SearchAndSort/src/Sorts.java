import java.security.SecureRandom;
import java.util.Arrays;

public class Sorts
{
    public int[] bubbleSort(int[] arrayToSort)
    {
        boolean done = false;
        int iterations = 0;
        while(!done)
        {
            done = true;
            iterations++;
            for (int i = 0; i < arrayToSort.length - 1; i++)
            {
                if(arrayToSort[i] > arrayToSort[i + 1])
                {
                    swap(arrayToSort, i, i + 1);
                    done = false;
                }
            }
        }
        System.out.println("It took " + iterations + " iterations to sort this array");
        return arrayToSort;
    }
    public void selectionSort(int[] numberArray) {
        int smallest = 0;
        int index = 0;
        for(int i=0; i<999; i++) {
            smallest = i;

            for(index=i+1; index<1000; index++) {
                if(numberArray[index] < numberArray[smallest]) {
                    smallest = index;
                    System.out.println(numberArray[smallest]);
                }
                System.out.println(numberArray[smallest]);
            }

            swap2(numberArray, i, smallest);
            printPass(numberArray, i+1, smallest);
        }
        System.out.println("The smallest number is " + numberArray[0]);

    }
    private static void printPass(int[] data, int pass, int index)
    {
        System.out.printf("after pass %2d: " , pass);

        for (int i =0; i < index; i++) {System.out.printf("%d   ", data[i]);}

        System.out.printf("%d* ", data[index]);

        for(int i = index +1; i < data.length; i++) {System.out.printf("%d   ", data[i]);}
        System.out.printf("%n               ");

        for (int j =0; j<pass; j++) {System.out.printf("--  ");}
        System.out.println();
    }
    private static void swap2(int[] data, int first, int second)
    {
        int temporary = data[first];
        data[first] = data[second];
        data[second] = temporary;
    }


    public void swap(int[] arrayToSwap, int indexOne, int indexTwo)
    {
        int temp = arrayToSwap[indexOne];
        arrayToSwap[indexOne] = arrayToSwap[indexTwo];
        arrayToSwap[indexTwo] = temp;
    }
}
