public class Driver
{

    public static void main(String[] args)
    {
        TextFileReader reader = new TextFileReader();
        int[] numberArray = reader.readFile("src/numbers.csv");
        printArray(numberArray);
        Sorts sorts = new Sorts();
        sorts.bubbleSort(numberArray);
        sorts.selectionSort(numberArray);
        printArray(numberArray);
        Searches searches = new Searches();
        searches.sequentialSearch(numberArray, 8427);
        searches.binarySearch(numberArray, 9992);
    }


    public static void printArray(int[] numberArray)
    {
        for(int i:numberArray)
        {
            System.out.println(i);
        }
    }
}
