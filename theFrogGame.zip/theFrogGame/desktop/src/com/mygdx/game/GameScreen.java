package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.World;
import helper.TileMapHelper;
import objects.player.Player;
import org.lwjgl.opengl.GL20;

import static helper.Constants.PPM;


public class GameScreen extends ScreenAdapter {


    //fields
    private OrthographicCamera camera;
    private SpriteBatch batch;
    private World world;
    private Box2DDebugRenderer box2DDebugRenderer;

    //map loaders
    private OrthogonalTiledMapRenderer orthogonalTiledMapRenderer;
    private TileMapHelper tileMapHelper;

    //game objects
    private Player player;




    //gameScreen Constructor
    public GameScreen(OrthographicCamera camera){
        this.camera = camera;
        this.batch = new SpriteBatch();

        // y value in constructor controls gravity
        this.world = new World(new Vector2(0,-25f), false);

        this.box2DDebugRenderer = new Box2DDebugRenderer();
        this.tileMapHelper = new TileMapHelper(this);
        this.orthogonalTiledMapRenderer = tileMapHelper.setUpMap();

    }

    //update method
    private void update() {
        //steppping the world
        world.step(1 / 60f, 6, 2);

        //batch management
        batch.setProjectionMatrix(camera.combined);

        //camera update
        cameraUpdate();

        //map updating
        orthogonalTiledMapRenderer.setView(camera);

        //player updating
        player.update();

        //escape
        if(Gdx.input.isKeyPressed(Input.Keys.ESCAPE)){
            Gdx.app.exit();
        }

    }//end of update

    //camera Update
    private void cameraUpdate() {
        Vector3 position = camera.position;
        position.x = Math.round(player.getBody().getPosition().x * PPM * 10) / 10f;
        position.y = Math.round(player.getBody().getPosition().y * PPM * 10) / 10f;
        camera.position.set(position);
        camera.update();
    }

    //render method
    public void render(float delta){
        //update
        this.update();

        //clr screen
        Gdx.gl.glClearColor(0,0,0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);


        //rednering the map (before the sprites)
        orthogonalTiledMapRenderer.render();

        batch.begin();
        //Batch objects:


        //end of batch
        batch.end();

        box2DDebugRenderer.render(world, camera.combined.scl(PPM));
    }//end of render

    //world getter
    public World getWorld() {
        return world;
    }

    //player setter
    public void setPlayer(Player player){
        this.player = player;
    }
}//end of GameScreen
