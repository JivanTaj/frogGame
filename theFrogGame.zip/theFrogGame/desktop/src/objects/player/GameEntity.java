package objects.player;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.physics.box2d.Body;

public abstract class GameEntity {


    //abstract fields for every game entity

    protected float x, y, velx, vely, speed;
    protected float width, height;
    protected Body body;

    //constructor
    public GameEntity(float width, float height, Body body){
        //setting it all up
        this.x = body.getPosition().x;
        this.y = body.getPosition().y;
        this.width = width;
        this.height = height;
        this.body = body;
        this.velx = 0;
        this.vely = 0;
        this.speed = 0;
    }

    //abstracts for gameEntity use
    public abstract void update();
    public abstract void render(SpriteBatch batch);

    //get body
    public Body getBody(){
        return body;
    }


}// end of class
