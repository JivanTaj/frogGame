package objects.player;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;

import static helper.Constants.PPM;

public class Player extends GameEntity {

    private int jumpCounter;

    //super constructor
    public Player(float width, float height, Body body) {
        super(width, height, body);
        // movement variable controls
        this.speed = 4f;
        this.jumpCounter = 0;
    }

    @Override
    public void update() {
        //updating x and y positions
        x = body.getPosition().x / PPM;
        y = body.getPosition().y / PPM;

        checkUserInput();

    }

    @Override
    public void render(SpriteBatch batch) {

    }


    private void checkUserInput(){
        velx = 0;
        //listening for horizontal movement input; A/D
            //D (right)
            if (Gdx.input.isKeyPressed(Input.Keys.D)){
                velx = 1;
            }//A (left)
            if (Gdx.input.isKeyPressed(Input.Keys.A)){
                velx = -1;
            }
        //listening for jump (Space)                               **| |** Set number of jumps here
        if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE) && jumpCounter < 2){
            //  Control jump force here **|  |**
            float force = body.getMass() * 18;
            body.setLinearVelocity(body.getLinearVelocity().x, 0);
            body.applyLinearImpulse(new Vector2(0, force), body.getPosition(), true);
            jumpCounter++;
        }
        //reset the jump counter
        if (body.getLinearVelocity().y == 0 ){
            jumpCounter = 0;
        }


        //apply velocity                                                   **|  | Edit terminal velocity here  | |**
        body.setLinearVelocity(velx * speed, body.getLinearVelocity().y < 25 ? body.getLinearVelocity().y : 25);


    }
}//end of class
