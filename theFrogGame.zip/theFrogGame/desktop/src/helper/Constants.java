package helper;

public class Constants {

    //game constants
    public static final float PPM =32.0f;
}
