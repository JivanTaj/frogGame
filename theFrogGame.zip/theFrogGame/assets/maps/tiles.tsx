<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="tiles" tilewidth="64" tileheight="64" tilecount="100" columns="10">
 <image source="tiles.png" width="640" height="640"/>
</tileset>
