import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class CarData
{
    public static void main(String[] args)
    {
        Scanner kb = new Scanner(System.in);
        TextFileReader reader = new TextFileReader();
        ArrayList<Driver> driverList = reader.readFile("driverData.csv");

        //.stream() converts our ArrayList into a stream
        //.filter(item -> predicate) takes an input stream and creates a filtered output stream based on the predicate
        //.map(item -> itemToMapTo) maps an item of one type to an item of another type in a 1-1 ratio
        //.reduce(numberToStartTheAccumulator, (accumulator, placeholder) -> operation) reduces the incoming stream
        //  to a single value
        //.foreach(item -> operationToPerformOnEachItem) performs the specified operation on each item in the stream

        // Example: Get the value of all the Honda Civics in the stream and get a total
        int i = driverList.stream().filter(m -> m.getCarMake().equalsIgnoreCase("honda"))
                .filter(n -> n.getCarModel().equalsIgnoreCase("civic"))
                .map(o -> o.getCurrentValue())
                .reduce(0, (total, count) -> total + count);
        System.out.println("\n Total value of Honda Civics: $" + i + "\n");


        // Solve each of the following problems using pipelines with lambdas as demonstrated above.
        // Problem 1: Print the first and last name of every driver that drives a Ford
        System.out.println("Ford owners: ");
        kb.nextLine();
        driverList.stream().filter(m -> m.getCarMake().equalsIgnoreCase("ford"))
                .forEach(driver -> System.out.println(driver.getFirstName() + " " + driver.getLastName()));
        // Problem 2: Get and print the total value of the GMC Yukons in the list
        int e = driverList.stream().filter(m -> m.getCarMake().equalsIgnoreCase("GMC"))
                .filter(n -> n.getCarModel().equalsIgnoreCase("Yukon"))
                .map(o -> o.getCurrentValue())
                .reduce(1, (total, count) -> total + count);
        System.out.println("\n Total value of GMV Yukons: $" + i + "\n");
        kb.nextLine();
        // Problem 3: Print the car make and model for any driver with the first name of Dollie
        System.out.println("Cars owned by people names Dollie: \n");
        kb.nextLine();

        driverList.stream().filter(m -> m.getFirstName().equalsIgnoreCase("dollie"))
                .forEach(driver -> System.out.println(driver.getCarMake() + ", " + driver.getCarModel()));
        System.out.println("\n");
        // Problem 4: Print the last name of any driver whose car is worth more than $10,000
        System.out.println("Last name of people with cars worth <= 10K : \n");
        kb.nextLine();
        driverList.stream().filter(m -> m.getCurrentValue() > 10000)
                .forEach(driver -> System.out.println(driver.getLastName()));
        // Problem 5: Print the first name and car model of any driver that owns a car made between
        //            2008 and 2014
        System.out.println("the first name and car model of any driver that owns a car made between 2008 and 2014: \n");
        kb.nextLine();

        driverList.stream().filter(m -> m.getCarYear().equals("2008") || m.getCarYear().equals("2009")
                                        || m.getCarYear().equals("2010") || m.getCarYear().equals("2011")
                                        || m.getCarYear().equals("2012") || m.getCarYear().equals("2013")
                                        || m.getCarYear().equals("2014"))
                .forEach(driver -> System.out.println(driver.getFirstName() + ", " + driver.getCarMake() + " " + driver.getCarModel()));
    }
}
